﻿using System;
using System.Windows.Forms;
using System.IO; //uses System.IO for streamreader//

/// <summary>
/// Brendan Burch 
/// 02/17/2018
/// Map data--
/// Provides visual and navigational references to criminal records throughout Pittsburgh
/// </summary>

namespace Burch_MapData
{
    public partial class MapDataForm : Form
    {
        private StreamReader fileReader; //instance variable for stream reader//

        public void ReadTextLine()//Method for Reading lines from File//
        {
            fileReader = new StreamReader(@"PittsburghArrestsCSV.csv"); //calls file to be read into method ReadTextLine & assigned to fileReader//

            while (!fileReader.EndOfStream)//While fileReader is not at the end of stream//
            {
                string text = fileReader.ReadLine(); //fileReader reads file and assigns internal values to 'String-text'//
                string[] args = text.Split(','); //creates a string array for values passed into text seperated by a comma//
                bool offense = DetermineArrestType(args[5]); //assigns offense the value of item 5 in the array//

                if (offense == true)
                {
                    //If offense is true a marker is put on the mapForm
                    //The coordinates are assigned through item 8(lattitude), & item 9(longitude) from the array//
                    CreateMapMarker(double.Parse(args[8]), double.Parse(args[9]));
                    Refresh();
                }
            }
            fileReader.Close();
            
        }

        public bool DetermineArrestType(string offense) //Method to check if search is compatible with file data//
        {
            
           
            if (offense.Contains(txtSearchText.Text))
            {
                return true;
                
            }
            else
            {
                return false;
            }
            
        }

        public void CreateMapMarker(double lattitude, double longitude)//Method for creating pushpins from googlemaps//
        {
            //Pushpins//

            gMap.MapProvider = GMap.NET.MapProviders.BingHybridMapProvider.Instance;
            GMap.NET.GMaps.Instance.Mode = GMap.NET.AccessMode.ServerOnly;
            gMap.ShowCenter = false; // Turns off red crosshairs for map form//
            GMap.NET.WindowsForms.GMapOverlay markers = new GMap.NET.WindowsForms.GMapOverlay("markers");
            GMap.NET.WindowsForms.GMapMarker marker = new GMap.NET.WindowsForms.Markers.GMarkerGoogle
                (new GMap.NET.PointLatLng(lattitude, longitude), GMap.NET.WindowsForms.Markers.GMarkerGoogleType.red_pushpin);
            gMap.SetPositionByKeywords("Pittsburgh, United States");
            gMap.Overlays.Add(markers);
            markers.Markers.Add(marker);

        }

        
        public MapDataForm()//main method//
        {
            InitializeComponent();

            fileReader = new StreamReader(@"PittsburghArrestsCSV.csv"); //instantiated streamreader inside MapDataForm//
        }

        private void MapDataForm_Load(object sender, EventArgs e)//Method used on formload//
        {
            gMap.MapProvider = GMap.NET.MapProviders.BingHybridMapProvider.Instance;
            GMap.NET.GMaps.Instance.Mode = GMap.NET.AccessMode.ServerOnly;
            gMap.ShowCenter = false;
            gMap.SetPositionByKeywords("Pittsburgh, United States");//on load, display is set to birdseye view of Pittsburgh//
        }

        private void btnSearch_Click(object sender, EventArgs e)//event for when button search is clicked//
        { 
                if (txtSearchText.Text != "") //Checks for text in textbox, if nothing program does nothing//
                {
                    ReadTextLine();
                }
            

            
            
        }
    }
}
