﻿using System;
using System.Windows.Forms;

namespace Burch_MapData
{
    static class MapData
    {
        
        
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MapDataForm());
        }
    }
}
